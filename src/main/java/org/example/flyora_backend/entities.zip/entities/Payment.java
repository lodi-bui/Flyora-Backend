package org.example.flyora_backend.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.example.flyora_backend.model.Order;

import java.time.Instant;

@Getter
@Setter
@Entity
public class Payment {
    @Id
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id")
    private Order order;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Size(max = 100)
    @Column(name = "status", length = 100)
    private String status;

    @Column(name = "paid_at")
    private Instant paidAt;

}